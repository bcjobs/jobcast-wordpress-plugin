Installing dev environment for this plugin:

1) Setup WordPress on your local server
